require_relative 'p05_hash_map'
# detects whether a string can be configured to a palindrome
def can_string_be_palindrome?(string)

end
