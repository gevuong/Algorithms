require_relative "static_array"

class DynamicArray
  attr_reader :length

  def initialize
    @store = StaticArray.new(8)
    @capacity = 8
    @length = 0
  end

  # O(1)
  def [](index)
    check_index(index)
    @store[index]
  end

  # O(1)
  def []=(index, value)
    @store[index] = value
  end

  # O(1)
  def pop
    check_index
    pop_val = @store[length - 1]
    @length -= 1
    @capacity -= 1
    pop_val
  end

  # O(1) ammortized; O(n) worst case. Variable because of the possible
  # resize.
  def push(val)
    if @length == @capacity
      resize!
    end
    self[length] = val
    @length += 1
    # @capacity += 1
  end

  # O(n): has to shift over all the elements.
  def shift
    check_index
    store_new = StaticArray.new(length - 1)
    (1...length).each do |idx|
      store_new[idx] = self[idx]
    end
    @store = store_new
    @length -= 1
  end

  # O(n): has to shift over all the elements.
  def unshift(val)
    store_new = StaticArray.new(length + 1)
    store_new[0] = val
    (0...length).each do |idx|
      store_new[idx + 1] = self[idx]
    end
    @store = store_new
    @length += 1
  end

  protected
  attr_accessor :capacity, :store
  attr_writer :length

  def check_index(index = 0)
    if index < length
      @store[index]
    else
      raise "index out of bounds"
    end  #unless index >= 0 && index < length
  end

  # O(n): has to copy over all the elements to the new store.
  def resize!
    new_store = StaticArray.new(length * 2) # doubles length of arr when capacity is reached
    (0...length).each { |i| new_store[i] = self[i] }
    @store = new_store
    @capacity = @capacity * 2 # thereforen need to double capacity
  end
end
